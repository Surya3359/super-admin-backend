export default function Footer() {
    return <footer class="bg-dark text-white text-center py-3">
    <div class="container">
        <p>&copy; 2024 My Blog. All rights reserved.</p>
    </div>
</footer>
}